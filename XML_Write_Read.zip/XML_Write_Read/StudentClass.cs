﻿using System;

namespace XML_Write_Read
{
	public class StudentClass
	{
		public string Name {get;set;}
		public int Class {get;set;}
		public string Subject {get;set;}
	}
}
