﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;

namespace XML_Write_Read
{
	public partial class MainForm : Form
	{
		XmlSerializer xmlSerial;
		List<StudentClass> lsStudentClass;
		
		public MainForm()
		{
			InitializeComponent();
			xmlSerial = new XmlSerializer(typeof(List<StudentClass>));
			lsStudentClass = new List<StudentClass>();
		}
		
		void BtnWriteClick(object sender, EventArgs e)
		{
			try {
				FileStream fileStream = new FileStream("student.xml", FileMode.Create, FileAccess.Write);
				StudentClass studentClass = new StudentClass();
				studentClass.Name = txtName.Text;
				studentClass.Class = int.Parse(txtClass.Text);
				studentClass.Subject = txtSubject.Text;
				lsStudentClass.Add(studentClass);
				xmlSerial.Serialize(fileStream, lsStudentClass);
				fileStream.Close();
			} catch (Exception) {
				MessageBox.Show("Check input values");
			}
		}
		
		void BtnReadClick(object sender, EventArgs e)
		{
			FileStream fileStream = new FileStream("student.xml", FileMode.Open, FileAccess.Read);
			lsStudentClass = (List<StudentClass>)xmlSerial.Deserialize(fileStream);
			dGV.DataSource = lsStudentClass;
			fileStream.Close();
		}
	}
}
