﻿/*
 * Created by SharpDevelop.
 * User: Main
 * Date: 10/20/2019
 * Time: 3:30 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace XML_Write_Read
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.txtName = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtClass = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtSubject = new System.Windows.Forms.TextBox();
			this.btnWrite = new System.Windows.Forms.Button();
			this.dGV = new System.Windows.Forms.DataGridView();
			this.btnRead = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.dGV)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(12, 22);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(49, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "Name";
			// 
			// txtName
			// 
			this.txtName.Location = new System.Drawing.Point(74, 19);
			this.txtName.Name = "txtName";
			this.txtName.Size = new System.Drawing.Size(180, 20);
			this.txtName.TabIndex = 1;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(12, 55);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(49, 23);
			this.label2.TabIndex = 2;
			this.label2.Text = "Class #";
			// 
			// txtClass
			// 
			this.txtClass.Location = new System.Drawing.Point(74, 52);
			this.txtClass.Name = "txtClass";
			this.txtClass.Size = new System.Drawing.Size(180, 20);
			this.txtClass.TabIndex = 3;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(12, 87);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(49, 23);
			this.label3.TabIndex = 4;
			this.label3.Text = "Subject";
			// 
			// txtSubject
			// 
			this.txtSubject.Location = new System.Drawing.Point(74, 84);
			this.txtSubject.Name = "txtSubject";
			this.txtSubject.Size = new System.Drawing.Size(180, 20);
			this.txtSubject.TabIndex = 5;
			// 
			// btnWrite
			// 
			this.btnWrite.Location = new System.Drawing.Point(269, 17);
			this.btnWrite.Name = "btnWrite";
			this.btnWrite.Size = new System.Drawing.Size(75, 23);
			this.btnWrite.TabIndex = 6;
			this.btnWrite.Text = "XML Write";
			this.btnWrite.UseVisualStyleBackColor = true;
			this.btnWrite.Click += new System.EventHandler(this.BtnWriteClick);
			// 
			// dGV
			// 
			this.dGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dGV.Location = new System.Drawing.Point(14, 182);
			this.dGV.Name = "dGV";
			this.dGV.Size = new System.Drawing.Size(617, 150);
			this.dGV.TabIndex = 7;
			// 
			// btnRead
			// 
			this.btnRead.Location = new System.Drawing.Point(556, 153);
			this.btnRead.Name = "btnRead";
			this.btnRead.Size = new System.Drawing.Size(75, 23);
			this.btnRead.TabIndex = 8;
			this.btnRead.Text = "Read XML";
			this.btnRead.UseVisualStyleBackColor = true;
			this.btnRead.Click += new System.EventHandler(this.BtnReadClick);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(643, 344);
			this.Controls.Add(this.btnRead);
			this.Controls.Add(this.dGV);
			this.Controls.Add(this.btnWrite);
			this.Controls.Add(this.txtSubject);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtClass);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtName);
			this.Controls.Add(this.label1);
			this.Name = "MainForm";
			this.Text = "XML Write Read";
			((System.ComponentModel.ISupportInitialize)(this.dGV)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();
		}
		private System.Windows.Forms.Button btnRead;
		private System.Windows.Forms.DataGridView dGV;
		private System.Windows.Forms.Button btnWrite;
		private System.Windows.Forms.TextBox txtSubject;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtClass;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox txtName;
		private System.Windows.Forms.Label label1;
	}
}
