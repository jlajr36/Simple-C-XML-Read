﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Xml;

namespace SimpleXML
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
			LoadEmployees();
		}
		
		private void LoadEmployees() {
			XmlDocument doc = new XmlDocument();
			doc.Load("Employee.xml");
			
			foreach (XmlNode node in doc.DocumentElement) {
				string name = node.Attributes[0].Value;
				int age = int.Parse(node["Age"].InnerText);
				bool isTrained = bool.Parse(node["IsTrained"].InnerText);
				listEmp.Items.Add(new Employee(name,age,isTrained));
			}
		}
		
		void ListEmpSelectedIndexChanged(object sender, EventArgs e)
		{
			if(listEmp.SelectedIndex != -1) {
				propEmp.SelectedObject = listEmp.SelectedItem;
			}
		}
	}
}
