﻿/*
 * Created by SharpDevelop.
 * User: Main
 * Date: 10/20/2019
 * Time: 8:03 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace SimpleXML
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.propEmp = new System.Windows.Forms.PropertyGrid();
			this.listEmp = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			// 
			// propEmp
			// 
			this.propEmp.Location = new System.Drawing.Point(12, 139);
			this.propEmp.Name = "propEmp";
			this.propEmp.Size = new System.Drawing.Size(288, 245);
			this.propEmp.TabIndex = 0;
			// 
			// listEmp
			// 
			this.listEmp.FormattingEnabled = true;
			this.listEmp.Location = new System.Drawing.Point(12, 12);
			this.listEmp.Name = "listEmp";
			this.listEmp.Size = new System.Drawing.Size(288, 121);
			this.listEmp.TabIndex = 1;
			this.listEmp.SelectedIndexChanged += new System.EventHandler(this.ListEmpSelectedIndexChanged);
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(312, 396);
			this.Controls.Add(this.listEmp);
			this.Controls.Add(this.propEmp);
			this.Name = "MainForm";
			this.Text = "SimpleXML";
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.ListBox listEmp;
		private System.Windows.Forms.PropertyGrid propEmp;
	}
}
