﻿using System;

namespace SimpleXML
{
	public class Employee
	{
		public string Name {get; private set;}
		public int Age {get; private set;}
		public bool IsTrained {get; private set;}
		
		public Employee(string name, int age, bool isTrained) {
			Name = name;
			Age = age;
			IsTrained = isTrained;
		}
		
		public override string ToString()
		{
			return Name;
		}
 
	}
}
